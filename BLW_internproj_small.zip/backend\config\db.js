// backend/config/db.js
import mongoose from "mongoose";

const DB_URI = process.env.MONGODB_URI || "mongodb+srv://temp_db:7905923814@shahswat.scembrc.mongodb.net/BLW?retryWrites=true&w=majority";

export const connectDB = async () => {
  try {
    await mongoose.connect(DB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log("🗄️  MongoDB connected");
  } catch (error) {
    console.error("❌ MongoDB connection error (non-fatal):", error);
    // Continue without exiting; API routes can handle missing DB gracefully
  }
};
