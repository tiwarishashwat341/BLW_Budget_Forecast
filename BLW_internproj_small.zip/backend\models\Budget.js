// backend/models/Budget.js
import mongoose from "mongoose";

const BudgetSchema = new mongoose.Schema(
  {
    department: { type: String, default: "BLW" }, // default for new schema (no department column)
    financialYear: { type: String, required: true },
    quarter: { type: String, required: true }, // e.g., "Q1", "Q2", "Q3", "Q4"
    budgetAllocated: { type: Number, required: true },
    budgetSpent: { type: Number, default: 0 },
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: "Admin" },
  },
  { timestamps: true }
);

export default mongoose.model("Budget", BudgetSchema);
