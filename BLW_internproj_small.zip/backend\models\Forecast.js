// backend/models/Forecast.js
import mongoose from "mongoose";

const ForecastSchema = new mongoose.Schema(
  {
    department: { type: String, required: true },
    forecastYear: { type: String, required: true },
    forecastQuarter: { type: String, required: true },
    predictedBudget: { type: Number, required: true },
    forecastingMethod: { type: String, default: "ARIMA" }, // e.g., ARIMA, SMA
  },
  { timestamps: { createdAt: "generatedAt", updatedAt: true } }
);

export default mongoose.model("Forecast", ForecastSchema);
