// backend/routes/auth.js
import express from "express";
import jwt from "jsonwebtoken";
import Admin from "../models/Admin.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET || "default_secret", {
    expiresIn: "10m",
  });
};

// @route   POST /api/auth/login
// @desc    Authenticate admin & return JWT token
router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const admin = await Admin.findOne({ email });
    if (admin && (await admin.comparePassword(password))) {
      res.json({
        _id: admin._id,
        username: admin.username,
        email: admin.email,
        role: admin.role,
        token: generateToken(admin._id),
      });
    } else {
      res.status(401).json({ message: "Invalid email or password" });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// @route   POST /api/auth/forgot-password
// @desc    Generate a temporary password for the admin
router.post("/forgot-password", async (req, res) => {
  const { email } = req.body;
  try {
    const admin = await Admin.findOne({ email });
    if (!admin) return res.status(404).json({ message: "Admin not found" });
    const tempPassword = Math.random().toString(36).slice(-8);
    admin.password = tempPassword; // pre-save hook will hash
    await admin.save();
    res.json({ message: "Temporary password generated", tempPassword });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// @route   GET /api/auth/me
// @desc    Get logged-in admin profile
router.get("/me", protect, async (req, res) => {
  res.json(req.admin);
});

// @route   POST /api/auth/change-password
// @desc    Change admin password while logged in
router.post("/change-password", protect, async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  try {
    const admin = await Admin.findById(req.admin._id);
    if (!admin) return res.status(404).json({ message: "Admin not found" });

    if (!(await admin.comparePassword(currentPassword))) {
      return res.status(401).json({ message: "Incorrect current password" });
    }

    admin.password = newPassword;
    await admin.save();

    res.json({ message: "Password updated successfully" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
