// backend/routes/budget.js
import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { parseExcel } from "../utils/excelParser.js";
import Budget from "../models/Budget.js";
import Forecast from "../models/Forecast.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

// Ensure upload directory exists
const uploadDir = path.join(process.cwd(), "backend", "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({ dest: uploadDir });

// Helper: quarter from date
const getQuarterStr = (date) => {
  const month = date.getMonth();
  return `Q${Math.floor(month / 3) + 1}`;
};

// ─────────────────────────────────────────────────────────────────────────────
// @route   DELETE /api/budget/reset
// @desc    Wipe ALL budget and forecast records (fresh start)
// ─────────────────────────────────────────────────────────────────────────────
router.delete("/reset", protect, async (req, res) => {
  try {
    const [bResult, fResult] = await Promise.all([
      Budget.deleteMany({}),
      Forecast.deleteMany({}),
    ]);
    res.json({
      message: "✅ All budget and forecast data cleared.",
      budgetsDeleted: bResult.deletedCount,
      forecastsDeleted: fResult.deletedCount,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// @route   POST /api/budget/upload
// @desc    Upload Excel – REPLACES all existing budget + forecast data
// ─────────────────────────────────────────────────────────────────────────────
router.post("/upload", protect, upload.single("file"), async (req, res) => {
  let tempPath = null;
  try {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }
    tempPath = req.file.path;
    const rows = parseExcel(tempPath);

    if (rows.length === 0) {
      return res.status(400).json({ message: "No valid data found in Excel file" });
    }

    let budgetDocs = [];

    if (rows[0]._schema === "new") {
      // ── New schema: Year | Quarter | Budget Allocated (₹ Lakhs) ─────────────
      budgetDocs = rows.map((row) => ({
        department: "BLW",
        financialYear: String(row.year).trim(),   // always string
        quarter: String(row.quarter).toUpperCase().trim(), // "Q1"…"Q4"
        budgetAllocated: Number(row.amount),
        budgetSpent: Number(row.amount),
        uploadedBy: req.admin._id,
      }));
    } else {
      // ── Legacy schema: Date | Department | Amount ─────────────────────────
      budgetDocs = rows.map((row) => {
        const { date, department, amount } = row;
        return {
          department: String(department).trim(),
          financialYear: String(date.getFullYear()),
          quarter: getQuarterStr(date),
          budgetAllocated: Number(amount),
          budgetSpent: Number(amount),
          uploadedBy: req.admin._id,
        };
      });
    }

    if (budgetDocs.length === 0) {
      return res.status(400).json({ message: "Parsed 0 valid rows — check file format" });
    }

    // ── WIPE existing data, then insert fresh ───────────────────────────────
    await Budget.deleteMany({});
    await Forecast.deleteMany({});

    await Budget.insertMany(budgetDocs, { ordered: false });

    // Clean up temp file
    if (tempPath && fs.existsSync(tempPath)) fs.unlinkSync(tempPath);

    // Return summary
    const years = [...new Set(budgetDocs.map((d) => d.financialYear))].sort();
    res.json({
      message: `✅ Uploaded ${budgetDocs.length} records (${years[0]}–${years[years.length - 1]}).  Click "Generate ARIMA Forecast" now.`,
      recordsImported: budgetDocs.length,
      yearsFound: years,
    });
  } catch (err) {
    if (tempPath && fs.existsSync(tempPath)) {
      try { fs.unlinkSync(tempPath); } catch (_) {}
    }
    console.error("Upload error:", err);
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// @route   GET /api/budget
// @desc    Get all budget records sorted by year then quarter
// ─────────────────────────────────────────────────────────────────────────────
router.get("/", protect, async (req, res) => {
  try {
    const budgets = await Budget.find()
      .sort({ financialYear: 1, quarter: 1 })
      .populate("uploadedBy", "username");
    res.json(budgets);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
