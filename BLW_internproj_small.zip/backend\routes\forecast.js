// backend/routes/forecast.js
import express from "express";
import Budget from "../models/Budget.js";
import Forecast from "../models/Forecast.js";
import { calculateARIMA } from "../utils/arimaCalculator.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

const QUARTERS = ["Q1", "Q2", "Q3", "Q4"];

/**
 * Build a quarter-specific time-series from ALL records (ignoring department),
 * then predict one step ahead with ARIMA(1,1,1).
 */
const buildQuarterForecasts = (allRecords) => {
  const results = [];

  for (const q of QUARTERS) {
    // Filter to this quarter, sort by year, extract values
    const series = allRecords
      .filter((r) => String(r.quarter).toUpperCase().trim() === q)
      .sort((a, b) => String(a.financialYear).localeCompare(String(b.financialYear)))
      .map((r) => Number(r.budgetAllocated));

    console.log(`[ARIMA] ${q} series (${series.length} pts):`, series);

    let predicted = 0;

    if (series.length === 0) {
      // No data for this quarter — use overall average
      const avg =
        allRecords.reduce((s, r) => s + Number(r.budgetAllocated), 0) /
        (allRecords.length || 1);
      predicted = Math.round(avg * 100) / 100;
      console.log(`[ARIMA] ${q} → no data, using global avg: ${predicted}`);
    } else if (series.length < 2) {
      // Only one data point — extrapolate slightly
      predicted = Math.round(series[0] * 1.05 * 100) / 100;
      console.log(`[ARIMA] ${q} → single point, extrapolated: ${predicted}`);
    } else {
      const [forecastedVal] = calculateARIMA(series, 1);
      predicted = Math.max(0, Math.round(forecastedVal * 100) / 100);
      console.log(`[ARIMA] ${q} → ARIMA forecast: ${predicted}`);
    }

    results.push({ quarter: q, predictedBudget: predicted });
  }

  return results;
};

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/forecast/generate
// ─────────────────────────────────────────────────────────────────────────────
router.post("/generate", protect, async (req, res) => {
  try {
    const allBudgets = await Budget.find().lean(); // .lean() for plain JS objects
    if (allBudgets.length === 0) {
      return res.status(400).json({ message: "No budget data found. Please upload your Excel first." });
    }

    // Determine next year from max financial year in the data
    const latestYear = allBudgets.reduce((max, b) => {
      const y = String(b.financialYear).trim();
      return y > max ? y : max;
    }, "0");

    const nextYear = String(parseInt(latestYear, 10) + 1);
    console.log(`[ARIMA] Latest year in DB: ${latestYear}  →  Forecasting for: ${nextYear}`);

    // Wipe ALL old forecasts first
    await Forecast.deleteMany({});

    // Generate quarter-wise ARIMA forecasts
    const quarterForecasts = buildQuarterForecasts(allBudgets);

    // Persist forecasts
    const saved = [];
    for (const { quarter, predictedBudget } of quarterForecasts) {
      const doc = await new Forecast({
        department: "BLW",
        forecastYear: nextYear,
        forecastQuarter: quarter,
        predictedBudget,
        forecastingMethod: "ARIMA(1,1,1)",
      }).save();
      saved.push(doc);
    }

    const total = saved.reduce((s, f) => s + f.predictedBudget, 0);

    res.json({
      message: `✅ ARIMA forecast generated for ${nextYear} — Q1–Q4`,
      targetYear: nextYear,
      total: Math.round(total * 100) / 100,
      forecasts: saved,
    });
  } catch (err) {
    console.error("[ARIMA generate error]", err);
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/forecast
// ─────────────────────────────────────────────────────────────────────────────
router.get("/", protect, async (req, res) => {
  try {
    const forecasts = await Forecast.find().sort({ forecastYear: 1, forecastQuarter: 1 });
    res.json(forecasts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
