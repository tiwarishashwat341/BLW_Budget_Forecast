import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Admin from './models/Admin.js';
import { connectDB } from './config/db.js';

dotenv.config();

const seedAdmin = async () => {
  try {
    await connectDB();
    
    const email = 'admin@example.com';
    const password = 'password123';
    
    // Check if admin already exists
    const adminExists = await Admin.findOne({ email });
    if (adminExists) {
      console.log('Admin already exists! You can login with:');
      console.log(`Email: ${email}`);
      console.log(`Password: ${password}`);
      process.exit(0);
    }
    
    // Create new admin
    const admin = await Admin.create({
      username: 'System Admin',
      email,
      password
    });
    
    console.log('Admin created successfully! You can login with:');
    console.log(`Email: ${email}`);
    console.log(`Password: ${password}`);
    process.exit(0);
  } catch (error) {
    console.error('Error seeding admin:', error.message);
    process.exit(1);
  }
};

seedAdmin();
