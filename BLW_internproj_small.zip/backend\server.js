// backend/server.js
import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import Admin from "./models/Admin.js";
import { connectDB } from './config/db.js';
import forecastRouter from './routes/forecast.js';
import authRouter from './routes/auth.js';
import budgetRouter from './routes/budget.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors({ origin: ["http://localhost:5173", "http://localhost:5174"] }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

connectDB();

// API routes
app.use('/api/auth', authRouter);
app.use('/api/budget', budgetRouter);
app.use('/api/forecast', forecastRouter);

// Serve built frontend
app.use(express.static(path.join(__dirname, '..', 'frontend', 'dist')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'frontend', 'dist', 'index.html'));
});

const PORT = 3962;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`🚀 Server running on http://0.0.0.0:${PORT}`);
});
