/**
 * arimaCalculator.js
 * 
 * Implements ARIMA(1,1,1) forecasting for budget prediction.
 * - d=1: first-order differencing to make series stationary
 * - AR(1): autoregressive component (uses lag-1)
 * - MA(1): moving average component (uses lag-1 error)
 * 
 * Returns predictions for `predictSteps` future periods.
 */

/**
 * Difference a time series once (d=1).
 * @param {number[]} series
 * @returns {number[]}
 */
const difference = (series) => {
  const diff = [];
  for (let i = 1; i < series.length; i++) {
    diff.push(series[i] - series[i - 1]);
  }
  return diff;
};

/**
 * Estimate AR(1) and MA(1) coefficients using a simplified
 * Yule-Walker + residual approach on the differenced series.
 * 
 * @param {number[]} diff - first-differenced series
 * @returns {{ phi: number, theta: number, mu: number }}
 */
const estimateARIMA11 = (diff) => {
  if (diff.length < 2) {
    return { phi: 0.5, theta: 0.2, mu: diff[0] || 0 };
  }

  // Mean of differenced series
  const mu = diff.reduce((s, v) => s + v, 0) / diff.length;

  // Demeaned series
  const dm = diff.map(v => v - mu);

  // Autocorrelation at lag 1 for AR coefficient (Yule-Walker)
  let num = 0, den = 0;
  for (let i = 1; i < dm.length; i++) {
    num += dm[i] * dm[i - 1];
    den += dm[i - 1] * dm[i - 1];
  }
  const phi = den > 0 ? Math.max(-0.95, Math.min(0.95, num / den)) : 0.3;

  // Compute AR(1) residuals to estimate MA(1) coefficient
  const residuals = [0]; // first residual assumed 0
  for (let i = 1; i < dm.length; i++) {
    residuals.push(dm[i] - phi * dm[i - 1] - 0); // ignoring MA for first pass
  }

  // MA coefficient: correlation between residual[i] and residual[i-1]
  let rNum = 0, rDen = 0;
  for (let i = 1; i < residuals.length; i++) {
    rNum += residuals[i] * residuals[i - 1];
    rDen += residuals[i - 1] * residuals[i - 1];
  }
  const theta = rDen > 0 ? Math.max(-0.95, Math.min(0.95, rNum / rDen)) : 0.1;

  return { phi, theta, mu };
};

/**
 * Forecast `steps` future values using ARIMA(1,1,1).
 * 
 * @param {number[]} series   - original (undifferenced) time series
 * @param {number}   steps    - number of steps to forecast (default: 4 for all quarters of next year)
 * @returns {number[]}        - array of `steps` forecasted values (original scale, rounded to 2 dp)
 */
export const calculateARIMA = (series, steps = 4) => {
  if (!series || series.length === 0) return Array(steps).fill(0);

  // Need at least 3 points for meaningful ARIMA(1,1,1)
  if (series.length < 3) {
    const avg = series.reduce((s, v) => s + v, 0) / series.length;
    const trend = series.length > 1 ? series[series.length - 1] - series[0] : 0;
    return Array.from({ length: steps }, (_, i) => Math.max(0, avg + trend * (i + 1)));
  }

  // Step 1: difference the series (d=1)
  const diff = difference(series);

  // Step 2: estimate ARIMA(1,1,1) parameters
  const { phi, theta, mu } = estimateARIMA11(diff);

  // Step 3: compute in-sample residuals for the MA component
  const demeaned = diff.map(v => v - mu);
  const residuals = [0];
  for (let i = 1; i < demeaned.length; i++) {
    const predicted = phi * demeaned[i - 1] + theta * residuals[i - 1];
    residuals.push(demeaned[i] - predicted);
  }

  // Step 4: forecast the differenced series h steps ahead
  const forecasts = [];
  let lastDiff = demeaned[demeaned.length - 1];
  let lastResidual = residuals[residuals.length - 1];

  for (let h = 0; h < steps; h++) {
    // For h > 1, expected residual = 0 (MA term vanishes beyond 1 step)
    const nextDiff = mu + phi * lastDiff + (h === 0 ? theta * lastResidual : 0);
    forecasts.push(nextDiff);
    lastDiff = nextDiff;
    lastResidual = 0; // residuals for future steps assumed 0
  }

  // Step 5: undo differencing to get original-scale forecasts
  let lastOriginal = series[series.length - 1];
  const result = [];
  for (const d of forecasts) {
    const next = lastOriginal + d;
    result.push(Math.max(0, Math.round(next * 100) / 100));
    lastOriginal = next;
  }

  return result;
};

