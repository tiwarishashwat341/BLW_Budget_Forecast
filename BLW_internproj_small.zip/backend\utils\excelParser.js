// backend/utils/excelParser.js
import xlsx from "xlsx";

/**
 * Parse an uploaded Excel file and return cleaned rows.
 *
 * Supported schema (new – primary):
 *   Year | Quarter | Budget Allocated (₹ Lakhs)
 *
 * Legacy schema (fallback):
 *   Date | Department | Amount
 */
export const parseExcel = (filePath) => {
  const workbook = xlsx.readFile(filePath, { cellDates: true });
  const sheetName = workbook.SheetNames[0];
  const sheet = workbook.Sheets[sheetName];
  const rawData = xlsx.utils.sheet_to_json(sheet, { defval: null });

  if (!rawData || rawData.length === 0) return [];

  const firstRow = rawData[0];
  const keys = Object.keys(firstRow);

  // ─── New schema detection ───────────────────────────────────────────────────
  const yearKey = keys.find((k) =>
    ["year"].includes(k.toLowerCase().trim())
  );
  const quarterKey = keys.find((k) =>
    ["quarter", "q"].includes(k.toLowerCase().trim())
  );
  const allocKey = keys.find((k) => {
    const lower = k.toLowerCase().trim();
    return (
      lower.includes("budget allocated") ||
      lower.includes("allocated") ||
      lower === "budget"
    );
  });

  if (yearKey && quarterKey && allocKey) {
    console.log(
      `New schema detected – Year: '${yearKey}', Quarter: '${quarterKey}', Allocated: '${allocKey}'`
    );

    const cleaned = rawData
      .filter(
        (row) =>
          row[yearKey] != null &&
          row[quarterKey] != null &&
          row[allocKey] != null
      )
      .map((row) => {
        const year = String(row[yearKey]).trim();
        const quarter = String(row[quarterKey]).trim().toUpperCase(); // "Q1"…"Q4"
        // Amount may be stored as number (already in Lakhs) or string
        const rawAmt = String(row[allocKey]).replace(/[^0-9.-]/g, "");
        const amount = parseFloat(rawAmt);

        return { year, quarter, amount };
      })
      .filter(
        (r) =>
          !isNaN(r.amount) &&
          /^\d{4}$/.test(r.year) &&
          /^Q[1-4]$/i.test(r.quarter)
      );

    return cleaned.map((r) => ({
      // tag so budget route knows which mode we're in
      _schema: "new",
      year: r.year,
      quarter: r.quarter,
      amount: r.amount,
    }));
  }

  // ─── Legacy schema fallback ─────────────────────────────────────────────────
  const dateKey = keys.find((k) =>
    ["date", "voucherdate", "po_date", "dpdt", "podate"].includes(
      k.toLowerCase().trim()
    )
  );
  const deptKey = keys.find((k) =>
    ["department", "spu", "consnm", "allocdesc", "vname", "dept"].includes(
      k.toLowerCase().trim()
    )
  );
  const amountKey = keys.find((k) =>
    [
      "amount",
      "netamt",
      "allocamount",
      "billamount",
      "po_value",
      "rate",
      "povalue",
    ].includes(k.toLowerCase().trim())
  );

  console.log(
    `Legacy schema – Date: '${dateKey}', Department: '${deptKey}', Amount: '${amountKey}'`
  );

  const activeDateKey = dateKey || "Date";
  const activeDeptKey = deptKey || "Department";
  const activeAmountKey = amountKey || "Amount";

  const cleaned = rawData
    .filter(
      (row) =>
        row[activeDateKey] != null &&
        row[activeDeptKey] != null &&
        row[activeAmountKey] != null
    )
    .map((row) => {
      let date;
      if (row[activeDateKey] instanceof Date) {
        date = row[activeDateKey];
      } else {
        date = new Date(row[activeDateKey]);
      }

      const department = String(row[activeDeptKey]).trim();
      const amount = Number(
        String(row[activeAmountKey]).replace(/[^0-9.-]/g, "")
      );

      return { _schema: "legacy", date, department, amount };
    })
    .filter((r) => !isNaN(r.date?.getTime()) && !isNaN(r.amount));

  return cleaned;
};
