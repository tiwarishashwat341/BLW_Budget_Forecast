import React from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer, Legend, Cell } from "recharts";

const COLORS = [
  "#6366f1", "#8b5cf6", "#a78bfa", "#c4b5fd",
  "#818cf8", "#7c3aed", "#4f46e5", "#5b21b6"
];

const BarChartComp = ({ data }) => {
  if (!Array.isArray(data) || data.length === 0) {
    return (
      <p style={{ color: "var(--color-muted)", fontSize: "14px", textAlign: "center", paddingTop: "40px" }}>
        No department data available.
      </p>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={data} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
        <CartesianGrid stroke="var(--chart-grid)" strokeDasharray="4" vertical={false} />
        <XAxis 
          dataKey="department" 
          tick={{ fill: "var(--color-muted)", fontSize: 11, fontFamily: "var(--font-family)" }}
          tickLine={{ stroke: "var(--border-color)" }}
          axisLine={{ stroke: "var(--border-color)" }}
        />
        <YAxis 
          tick={{ fill: "var(--color-muted)", fontSize: 11, fontFamily: "var(--font-family)" }}
          tickLine={{ stroke: "var(--border-color)" }}
          axisLine={{ stroke: "var(--border-color)" }}
          tickFormatter={(value) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', notation: "compact" }).format(value)}
        />
        <Tooltip 
          formatter={(value) => [new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(value), "Spent"]}
          contentStyle={{ 
            backgroundColor: "var(--chart-tooltip-bg)", 
            borderColor: "var(--chart-tooltip-border)",
            borderRadius: "8px",
            color: "var(--chart-tooltip-text)",
            fontFamily: "var(--font-family)",
            fontSize: "12px",
            boxShadow: "var(--shadow-md)"
          }}
          itemStyle={{ color: "var(--chart-tooltip-text)" }}
          labelStyle={{ color: "var(--color-muted)", fontWeight: 600, marginBottom: "4px" }}
        />
        <Bar 
          dataKey="amount" 
          radius={[6, 6, 0, 0]} 
          maxBarSize={50}
          name="Budget Spent"
        >
          {data.map((_, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
};

export default BarChartComp;
