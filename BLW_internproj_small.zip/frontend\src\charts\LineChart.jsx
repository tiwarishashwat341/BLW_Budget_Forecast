import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
} from "recharts";

const LineChartComp = ({ data }) => {
  const chartData = Array.isArray(data)
    ? data.map((d) => ({
        quarter: d.quarter,
        Actual: d.actualAmount != null ? d.actualAmount : null,
        Predicted: d.predictedAmount != null ? d.predictedAmount : null,
      }))
    : [];

  // With 20+ points, rotate labels and skip every other one to avoid overlap
  const totalPoints = chartData.length;
  const tickInterval = totalPoints > 12 ? 1 : 0; // every 2nd tick when dense

  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart
        data={chartData}
        margin={{ top: 10, right: 10, left: -10, bottom: 50 }}
      >
        <CartesianGrid
          stroke="var(--chart-grid)"
          strokeDasharray="4"
          vertical={false}
        />
        <XAxis
          dataKey="quarter"
          interval={tickInterval}
          angle={-45}
          textAnchor="end"
          tick={{
            fill: "var(--color-muted)",
            fontSize: 10,
            fontFamily: "var(--font-family)",
          }}
          tickLine={{ stroke: "var(--border-color)" }}
          axisLine={{ stroke: "var(--border-color)" }}
          height={60}
        />
        <YAxis
          tick={{
            fill: "var(--color-muted)",
            fontSize: 11,
            fontFamily: "var(--font-family)",
          }}
          tickLine={false}
          axisLine={false}
          tickFormatter={(v) =>
            new Intl.NumberFormat("en-IN", {
              notation: "compact",
              maximumFractionDigits: 1,
            }).format(v)
          }
        />
        <Tooltip
          formatter={(value, name) => [
            `₹${new Intl.NumberFormat("en-IN", {
              maximumFractionDigits: 2,
            }).format(value)} L`,
            name,
          ]}
          contentStyle={{
            backgroundColor: "var(--chart-tooltip-bg)",
            borderColor: "var(--chart-tooltip-border)",
            borderRadius: "8px",
            color: "var(--chart-tooltip-text)",
            fontFamily: "var(--font-family)",
            fontSize: "12px",
            boxShadow: "var(--shadow-md)",
          }}
          itemStyle={{ color: "var(--chart-tooltip-text)" }}
          labelStyle={{
            color: "var(--color-muted)",
            fontWeight: 600,
            marginBottom: "4px",
          }}
        />
        <Legend
          wrapperStyle={{
            fontFamily: "var(--font-family)",
            fontSize: "12px",
            paddingTop: "10px",
          }}
        />
        <Line
          type="monotone"
          dataKey="Actual"
          stroke="var(--chart-actual)"
          strokeWidth={2.5}
          dot={{ r: 3, strokeWidth: 1, fill: "var(--bg-card)" }}
          activeDot={{ r: 5, strokeWidth: 0 }}
          connectNulls={false}
        />
        <Line
          type="monotone"
          dataKey="Predicted"
          stroke="var(--chart-pred)"
          strokeWidth={2}
          strokeDasharray="5 5"
          dot={{ r: 3, strokeWidth: 1, fill: "var(--bg-card)" }}
          activeDot={{ r: 5, strokeWidth: 0 }}
          connectNulls={false}
        />
      </LineChart>
    </ResponsiveContainer>
  );
};

export default LineChartComp;
