import React from "react";
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from "recharts";

const COLORS = [
  "#6366f1", "#8b5cf6", "#ec4899", "#f43f5e",
  "#f59e0b", "#10b981", "#06b6d4", "#3b82f6"
];

const PieChartComp = ({ data }) => {
  if (!Array.isArray(data) || data.length === 0) {
    return (
      <p style={{ color: "var(--color-muted)", fontSize: "14px", textAlign: "center", paddingTop: "40px" }}>
        No department data available.
      </p>
    );
  }

  const renderCustomLabel = ({ name, percent }) => {
    return `${name} (${(percent * 100).toFixed(0)}%)`;
  };

  return (
    <ResponsiveContainer width="100%" height={300}>
      <PieChart>
        <Pie 
          data={data} 
          dataKey="value" 
          nameKey="name" 
          cx="50%" 
          cy="50%" 
          outerRadius={90}
          innerRadius={40}
          stroke="var(--bg-card)" 
          strokeWidth={3}
          label={renderCustomLabel}
          labelLine={{ stroke: "var(--color-muted)", strokeWidth: 1 }}
        >
          {data.map((_, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip 
          formatter={(value) => `₹${value.toLocaleString()}`}
          contentStyle={{ 
            backgroundColor: "var(--chart-tooltip-bg)", 
            borderColor: "var(--chart-tooltip-border)",
            borderRadius: "8px",
            color: "var(--chart-tooltip-text)",
            fontFamily: "var(--font-family)",
            fontSize: "12px",
            boxShadow: "var(--shadow-md)"
          }}
          itemStyle={{ color: "var(--chart-tooltip-text)" }}
        />
        <Legend 
          wrapperStyle={{ 
            fontFamily: "var(--font-family)", 
            fontSize: "12px",
            paddingTop: "15px"
          }}
        />
      </PieChart>
    </ResponsiveContainer>
  );
};

export default PieChartComp;
