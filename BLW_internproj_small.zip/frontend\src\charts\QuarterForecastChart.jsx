import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
  LabelList,
  Legend,
  Cell,
} from "recharts";

const FORECAST_COLORS = {
  Q1: "#6366f1",
  Q2: "#8b5cf6",
  Q3: "#a78bfa",
  Q4: "#c084fc",
};
const FALLBACK = ["#6366f1", "#8b5cf6", "#a78bfa", "#c084fc"];

/**
 * QuarterForecastChart
 *
 * Props:
 *   data  : [{ quarter, predictedBudget, historicalAvg? }]
 *   year  : string, e.g. "2026"
 *   unit  : string, e.g. "Lakhs"
 */
const QuarterForecastChart = ({ data = [], year = "", unit = "Lakhs" }) => {
  if (!Array.isArray(data) || data.length === 0) {
    return (
      <p
        style={{
          color: "var(--color-muted)",
          fontSize: "14px",
          textAlign: "center",
          paddingTop: "40px",
        }}
      >
        No forecast data available. Upload data and generate a forecast first.
      </p>
    );
  }

  const chartData = data.map((d) => ({
    quarter: d.quarter,
    [`Forecast ${year}`]: d.predictedBudget ?? 0,
    "Historical Avg": d.historicalAvg ?? 0,
  }));

  const fmt = (v) =>
    `₹${new Intl.NumberFormat("en-IN", { maximumFractionDigits: 1 }).format(v)} ${unit}`;

  const compact = (v) =>
    `₹${new Intl.NumberFormat("en-IN", {
      notation: "compact",
      maximumFractionDigits: 1,
    }).format(v)}`;

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null;
    return (
      <div
        style={{
          backgroundColor: "var(--chart-tooltip-bg)",
          border: "1px solid var(--chart-tooltip-border)",
          borderRadius: "10px",
          padding: "10px 14px",
          fontFamily: "var(--font-family)",
          fontSize: "13px",
          color: "var(--chart-tooltip-text)",
          boxShadow: "var(--shadow-md)",
        }}
      >
        <p style={{ margin: "0 0 6px", fontWeight: 700, color: "var(--color-muted)" }}>
          {label}
        </p>
        {payload.map((p) => (
          <p key={p.name} style={{ margin: "2px 0", color: p.fill, fontWeight: 600 }}>
            {p.name}: {fmt(p.value)}
          </p>
        ))}
      </div>
    );
  };

  return (
    <ResponsiveContainer width="100%" height={320}>
      <BarChart
        data={chartData}
        margin={{ top: 24, right: 20, left: -5, bottom: 0 }}
        barCategoryGap="25%"
        barGap={4}
      >
        <CartesianGrid stroke="var(--chart-grid)" strokeDasharray="4" vertical={false} />
        <XAxis
          dataKey="quarter"
          tick={{
            fill: "var(--color-muted)",
            fontSize: 13,
            fontFamily: "var(--font-family)",
            fontWeight: 700,
          }}
          tickLine={false}
          axisLine={{ stroke: "var(--border-color)" }}
        />
        <YAxis
          tick={{
            fill: "var(--color-muted)",
            fontSize: 11,
            fontFamily: "var(--font-family)",
          }}
          tickLine={false}
          axisLine={false}
          tickFormatter={compact}
        />
        <Tooltip content={<CustomTooltip />} />
        <Legend
          wrapperStyle={{
            fontFamily: "var(--font-family)",
            fontSize: "12px",
            paddingTop: "12px",
          }}
        />

        {/* Forecast bar – per-quarter color */}
        <Bar
          dataKey={`Forecast ${year}`}
          radius={[7, 7, 0, 0]}
          maxBarSize={54}
        >
          {chartData.map((entry, i) => (
            <Cell
              key={`cell-${i}`}
              fill={FORECAST_COLORS[entry.quarter] || FALLBACK[i % 4]}
            />
          ))}
          <LabelList
            dataKey={`Forecast ${year}`}
            position="top"
            formatter={compact}
            style={{
              fontSize: "11px",
              fill: "var(--color-muted)",
              fontFamily: "var(--font-family)",
              fontWeight: 700,
            }}
          />
        </Bar>

        {/* Historical Average bar – neutral grey */}
        <Bar
          dataKey="Historical Avg"
          fill="rgba(150,150,170,0.35)"
          radius={[7, 7, 0, 0]}
          maxBarSize={54}
        >
          <LabelList
            dataKey="Historical Avg"
            position="top"
            formatter={compact}
            style={{
              fontSize: "10px",
              fill: "var(--color-muted)",
              fontFamily: "var(--font-family)",
            }}
          />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
};

export default QuarterForecastChart;
