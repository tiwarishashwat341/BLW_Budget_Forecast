import React from "react";
import { useLocation } from "react-router-dom";
import "./Header.css";
import logo from "../assets/logo.png";

const Header = () => {
  const location = useLocation();
  const isAuthPage = location.pathname === "/login" || location.pathname === "/forgot-password";

  return (
    <header className="header">
      <div className="header-brand">
        <img src={logo} alt="BLW Logo" className="header-logo-img" />
        <h1 className="header-title">BLW Analytics</h1>
      </div>
      {!isAuthPage && (
        <nav className="header-nav">
          <button className="btn-logout" onClick={() => {
            localStorage.removeItem("adminToken");
            localStorage.removeItem("adminUser");
            window.location.href = "/login";
          }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{marginRight: '6px'}}>
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
              <polyline points="16 17 21 12 16 7"></polyline>
              <line x1="21" y1="12" x2="9" y2="12"></line>
            </svg>
            Logout
          </button>
        </nav>
      )}
    </header>
  );
};

export default Header;
