import React, { useEffect, useState } from "react";
import axios from "axios";
import "./BudgetManagement.css";

const BudgetManagement = ({ refreshTrigger }) => {
  const [budgets, setBudgets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filterYear, setFilterYear] = useState("");

  const fetchBudgets = async () => {
    try {
      const token = localStorage.getItem("adminToken");
      const res = await axios.get("http://localhost:3962/api/budget", {
        headers: { Authorization: `Bearer ${token}` }
      });
      setBudgets(res.data);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to load budgets");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBudgets();
  }, [refreshTrigger]);

  if (loading) {
    return (
      <div className="budget-management">
        <div style={{ textAlign: "center", padding: "3rem", color: "var(--color-muted)" }}>
          <span className="spinner"></span>
          <p>Loading budget records...</p>
        </div>
      </div>
    );
  }

  if (error) return <div className="alert error">{error}</div>;

  // Get unique years for filter
  const years = [...new Set(budgets.map(b => b.financialYear))].sort();
  const filtered = filterYear ? budgets.filter(b => b.financialYear === filterYear) : budgets;

  return (
    <div className="budget-management">
      <h3>Budget Records</h3>
      <p>{budgets.length} records across {years.length} year{years.length !== 1 ? "s" : ""}</p>

      {/* Year filter */}
      {years.length > 0 && (
        <div style={{ marginBottom: "1rem" }}>
          <select
            value={filterYear}
            onChange={(e) => setFilterYear(e.target.value)}
            style={{
              padding: "0.5rem 0.75rem",
              borderRadius: "var(--radius-sm, 8px)",
              border: "1px solid var(--border-color)",
              backgroundColor: "var(--bg-card)",
              color: "var(--color-primary)",
              fontFamily: "var(--font-family)",
              fontSize: "0.8125rem",
              cursor: "pointer",
              outline: "none"
            }}
          >
            <option value="">All Years</option>
            {years.map(y => (
              <option key={y} value={y}>{y}</option>
            ))}
          </select>
        </div>
      )}

      {filtered.length === 0 ? (
        <p style={{ color: "var(--color-muted)", textAlign: "center", padding: "2rem" }}>
          No budget records found.
        </p>
      ) : (
        <div className="table-responsive">
          <table className="data-table">
            <thead>
              <tr>
                <th>Financial Year</th>
                <th>Quarter</th>
                <th>Budget Allocated (₹ Lakhs)</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((b) => (
                <tr key={b._id}>
                  <td style={{ fontWeight: 600 }}>{b.financialYear}</td>
                  <td>
                    <span className="quarter-badge-sm">{b.quarter}</span>
                  </td>
                  <td>{new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 }).format(b.budgetAllocated || 0)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default BudgetManagement;
