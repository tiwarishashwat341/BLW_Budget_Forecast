import React, { useEffect, useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import DataUpload from "./DataUpload";
import BudgetManagement from "./BudgetManagement";
import LineChartComp from "../charts/LineChart";
import BarChartComp from "../charts/BarChart";
import PieChartComp from "../charts/PieChart";
import QuarterForecastChart from "../charts/QuarterForecastChart";
import jsPDF from "jspdf";
import "jspdf-autotable";
import * as XLSX from "xlsx";
import "./Dashboard.css";

const API = "http://localhost:3962/api";

const Dashboard = () => {
  const [budgets, setBudgets] = useState([]);
  const [forecasts, setForecasts] = useState([]);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [generating, setGenerating] = useState(false);
  const [forecastMessage, setForecastMessage] = useState("");
  const [activeTab, setActiveTab] = useState("overview");
  const navigate = useNavigate();

  // Settings state
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [settingsMsg, setSettingsMsg] = useState("");

  const handleLogout = () => {
    localStorage.removeItem("adminToken");
    localStorage.removeItem("adminUser");
    navigate("/login");
  };

  const fetchData = async () => {
    try {
      const token = localStorage.getItem("adminToken");
      const [budgetRes, forecastRes] = await Promise.all([
        axios.get(`${API}/budget`, { headers: { Authorization: `Bearer ${token}` } }),
        axios.get(`${API}/forecast`, { headers: { Authorization: `Bearer ${token}` } }),
      ]);
      setBudgets(budgetRes.data);
      setForecasts(forecastRes.data);
    } catch (err) {
      console.error(err);
      if (err.response?.status === 401) handleLogout();
    }
  };

  useEffect(() => {
    fetchData();
  }, [refreshTrigger]);

  const handleUploadSuccess = () => setRefreshTrigger((p) => p + 1);

  const generateForecast = async () => {
    setGenerating(true);
    setForecastMessage("");
    try {
      const token = localStorage.getItem("adminToken");
      const res = await axios.post(`${API}/forecast/generate`, {}, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setForecastMessage(res.data.message);
      setRefreshTrigger((p) => p + 1);
    } catch (err) {
      setForecastMessage(err.response?.data?.message || "Failed to generate forecast.");
    } finally {
      setGenerating(false);
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem("adminToken");
      const res = await axios.post(
        `${API}/auth/change-password`,
        { currentPassword, newPassword },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setSettingsMsg(res.data.message);
      setCurrentPassword("");
      setNewPassword("");
    } catch (err) {
      setSettingsMsg(err.response?.data?.message || "Failed to change password");
    }
  };

  // ── Export helpers ─────────────────────────────────────────────────────────
  const exportToExcel = () => {
    const wsData = budgets.map((b) => ({
      "Financial Year": b.financialYear,
      Quarter: b.quarter,
      "Budget Allocated (₹ Lakhs)": b.budgetAllocated,
    }));
    const ws = XLSX.utils.json_to_sheet(wsData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Budget Report");
    XLSX.writeFile(wb, "blw_budget_report.xlsx");
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("BLW Budget Report", 14, 15);
    const tableData = budgets.map((b) => [
      b.financialYear,
      b.quarter,
      b.budgetAllocated,
    ]);
    doc.autoTable({
      head: [["Year", "Quarter", "Allocated (₹ Lakhs)"]],
      body: tableData,
      startY: 20,
    });
    doc.save("blw_budget_report.pdf");
  };

  // ── Derived data ───────────────────────────────────────────────────────────
  const totalAllocated = budgets.reduce((s, b) => s + (b.budgetAllocated || 0), 0);
  const uniqueYears = new Set(budgets.map((b) => b.financialYear)).size;

  // Latest forecast year (the year we're predicting)
  const forecastYear = forecasts.length > 0
    ? forecasts.reduce((max, f) => (f.forecastYear > max ? f.forecastYear : max), "0")
    : null;

  // All forecasts for the latest year, grouped by quarter
  const nextYearForecasts = forecastYear
    ? ["Q1", "Q2", "Q3", "Q4"].map((q) => {
        const match = forecasts.find(
          (f) => f.forecastYear === forecastYear && f.forecastQuarter === q
        );
        return {
          quarter: q,
          predictedBudget: match ? match.predictedBudget : 0,
        };
      })
    : [];

  const totalForecast = nextYearForecasts.reduce((s, f) => s + (f.predictedBudget || 0), 0);

  // ── Chart data transforms ──────────────────────────────────────────────────
  // Time-series line chart: actual budget per period
  const timeChartData = useMemo(() => {
    const map = {};
    budgets.forEach((b) => {
      const key = `${b.financialYear}-${b.quarter}`;
      if (!map[key]) map[key] = { quarter: key, actualAmount: 0 };
      map[key].actualAmount += b.budgetAllocated;
    });
    // Append forecast points
    nextYearForecasts.forEach((f) => {
      if (!f.predictedBudget) return;
      const key = `${forecastYear}-${f.quarter}`;
      if (!map[key]) map[key] = { quarter: key };
      map[key].predictedAmount = (map[key].predictedAmount || 0) + f.predictedBudget;
    });
    return Object.values(map).sort((a, b) => a.quarter.localeCompare(b.quarter));
  }, [budgets, nextYearForecasts, forecastYear]);

  // Quarter-wise total allocation bar chart (summed across all years)
  const quarterBarMap = { Q1: 0, Q2: 0, Q3: 0, Q4: 0 };
  budgets.forEach((b) => {
    if (quarterBarMap[b.quarter] !== undefined)
      quarterBarMap[b.quarter] += b.budgetAllocated;
  });
  const barChartData = Object.entries(quarterBarMap).map(([q, amount]) => ({
    department: q,   // reuse 'department' key so BarChart component works unchanged
    amount,
  }));
  const pieChartData = barChartData.map((d) => ({ name: d.department, value: d.amount }));

  // Quarter-wise historical average (to compare with forecast)
  const qAvgMap = useMemo(() => {
    const qMap = { Q1: [], Q2: [], Q3: [], Q4: [] };
    budgets.forEach((b) => {
      if (qMap[b.quarter]) qMap[b.quarter].push(b.budgetAllocated);
    });
    const result = {};
    for (const q of ["Q1", "Q2", "Q3", "Q4"]) {
      const arr = qMap[q];
      result[q] = arr.length > 0 ? arr.reduce((s, v) => s + v, 0) / arr.length : 0;
    }
    return result;
  }, [budgets]);

  // Enrich forecast data with historical average for chart
  const enrichedForecast = nextYearForecasts.map((f) => ({
    ...f,
    historicalAvg: qAvgMap[f.quarter] || 0,
  }));

  // ── Format helpers ─────────────────────────────────────────────────────────
  const fmtLakhs = (v) =>
    `₹${new Intl.NumberFormat("en-IN", { maximumFractionDigits: 1 }).format(v)} L`;

  return (
    <div className="dashboard">
      <div className="dashboard-header-bar">
        <div>
          <h2 className="dashboard-title">Dashboard Overview</h2>
          <p className="dashboard-subtitle">BLW Financial Analytics &amp; Forecasting</p>
        </div>
        <div style={{ display: "flex", gap: "10px" }}>
          <button className="btn-outline" onClick={exportToExcel}>Export Excel</button>
          <button className="btn-outline" onClick={exportToPDF}>Export PDF</button>
        </div>
      </div>

      {/* Tab Navigation */}
      <nav className="tab-nav">
        <button
          className={`tab-btn ${activeTab === "overview" ? "active" : ""}`}
          onClick={() => setActiveTab("overview")}
        >
          Overview
        </button>
        <button
          className={`tab-btn ${activeTab === "forecast" ? "active" : ""}`}
          onClick={() => setActiveTab("forecast")}
        >
          📊 Forecast {forecastYear && `(${forecastYear})`}
        </button>
        <button
          className={`tab-btn ${activeTab === "upload" ? "active" : ""}`}
          onClick={() => setActiveTab("upload")}
        >
          Upload &amp; Generate
        </button>
        <button
          className={`tab-btn ${activeTab === "records" ? "active" : ""}`}
          onClick={() => setActiveTab("records")}
        >
          Budget Records
        </button>
        <button
          className={`tab-btn ${activeTab === "settings" ? "active" : ""}`}
          onClick={() => setActiveTab("settings")}
        >
          Settings
        </button>
      </nav>

      {/* ===== OVERVIEW TAB ===== */}
      {activeTab === "overview" && (
        <>
          {/* Summary cards */}
          <section className="summary-cards">
            <div className="card summary-card card-allocated">
              <span className="label-caps summary-card-title">Total Allocated</span>
              <p className="summary-card-value">{fmtLakhs(totalAllocated)}</p>
              <span className="summary-card-meta">{budgets.length} records</span>
            </div>
            <div className="card summary-card card-spent">
              <span className="label-caps summary-card-title">Years of Data</span>
              <p className="summary-card-value">{uniqueYears}</p>
              <span className="summary-card-meta">historical years</span>
            </div>
            <div className="card summary-card card-forecast">
              <span className="label-caps summary-card-title">
                ARIMA Forecast {forecastYear ? `(${forecastYear})` : ""}
              </span>
              <p className="summary-card-value">{fmtLakhs(totalForecast)}</p>
              <span className="summary-card-meta">annual prediction</span>
            </div>
            <div className="card summary-card card-savings">
              <span className="label-caps summary-card-title">Forecast vs Historical</span>
              <p className="summary-card-value">
                {totalAllocated > 0
                  ? `${((totalForecast / (totalAllocated / (budgets.length / 4 || 1))) * 100 - 100).toFixed(1)}%`
                  : "—"}
              </p>
              <span className="summary-card-meta">growth estimate</span>
            </div>
          </section>

          <section className="charts-grid">
            <div className="card chart-card chart-card-wide">
              <div className="chart-card-header">
                <div>
                  <h3 className="chart-card-title">Budget Trend – Actual vs Predicted</h3>
                  <span className="label-caps">Quarter-by-quarter time series</span>
                </div>
              </div>
              <div className="chart-container">
                <LineChartComp data={timeChartData} />
              </div>
            </div>

            <div className="card chart-card">
              <div className="chart-card-header">
                <div>
                  <h3 className="chart-card-title">Quarter-wise Total Allocation</h3>
                  <span className="label-caps">Cumulative budget per quarter (all years)</span>
                </div>
              </div>
              <div className="chart-container">
                <BarChartComp data={barChartData} />
              </div>
            </div>

            <div className="card chart-card">
              <div className="chart-card-header">
                <div>
                  <h3 className="chart-card-title">Quarter Distribution</h3>
                  <span className="label-caps">Budget share by quarter</span>
                </div>
              </div>
              <div className="chart-container">
                <PieChartComp data={pieChartData} />
              </div>
            </div>
          </section>
        </>
      )}

      {/* ===== FORECAST TAB ===== */}
      {activeTab === "forecast" && (
        <div className="forecast-tab">
          {/* Year banner */}
          {forecastYear ? (
            <div className="forecast-year-banner">
              <div className="forecast-year-badge">
                <span className="forecast-year-label">ARIMA Forecast Year</span>
                <span className="forecast-year-value">{forecastYear}</span>
              </div>
              <div className="forecast-year-total">
                <span className="label-caps">Total Annual Prediction</span>
                <p className="forecast-total-value">{fmtLakhs(totalForecast)}</p>
              </div>
            </div>
          ) : (
            <div className="forecast-empty-banner">
              <span>⚠️ No forecast generated yet. Go to <strong>Upload &amp; Generate</strong> to create one.</span>
            </div>
          )}

          {/* Quarter prediction cards */}
          {forecastYear && (
            <>
              <section className="quarter-cards">
                {nextYearForecasts.map(({ quarter, predictedBudget }) => {
                  const hist = qAvgMap[quarter] || 0;
                  const delta = hist > 0 ? ((predictedBudget - hist) / hist) * 100 : 0;
                  const positive = delta >= 0;
                  return (
                    <div key={quarter} className={`card quarter-card quarter-card-${quarter.toLowerCase()}`}>
                      <div className="quarter-card-header">
                        <span className="quarter-badge">{quarter}</span>
                        <span className={`delta-badge ${positive ? "delta-up" : "delta-down"}`}>
                          {positive ? "▲" : "▼"} {Math.abs(delta).toFixed(1)}%
                        </span>
                      </div>
                      <p className="quarter-predicted-value">{fmtLakhs(predictedBudget)}</p>
                      <span className="quarter-hist-label">
                        Hist. avg: {fmtLakhs(hist)}
                      </span>
                    </div>
                  );
                })}
              </section>

              {/* Quarter-wise bar chart */}
              <div className="card chart-card chart-card-wide" style={{ marginTop: "1.5rem" }}>
                <div className="chart-card-header">
                  <div>
                    <h3 className="chart-card-title">
                      Quarter-wise ARIMA Prediction for {forecastYear}
                    </h3>
                    <span className="label-caps">
                      Budget Allocated (₹ Lakhs) – predicted per quarter
                    </span>
                  </div>
                </div>
                <div className="chart-container">
                  <QuarterForecastChart
                    data={enrichedForecast}
                    year={forecastYear}
                    unit="Lakhs"
                  />
                </div>
              </div>

              {/* ARIMA details table */}
              <div className="card forecast-table-card" style={{ marginTop: "1.5rem" }}>
                <div className="chart-card-header">
                  <h3 className="chart-card-title">Forecast Detail</h3>
                </div>
                <div className="forecast-table-wrapper">
                  <table className="forecast-table">
                    <thead>
                      <tr>
                        <th>Year</th>
                        <th>Quarter</th>
                        <th>Predicted Budget (₹ Lakhs)</th>
                        <th>Hist. Avg (₹ Lakhs)</th>
                        <th>Δ Change</th>
                        <th>Method</th>
                      </tr>
                    </thead>
                    <tbody>
                      {nextYearForecasts.map(({ quarter, predictedBudget }) => {
                        const hist = qAvgMap[quarter] || 0;
                        const delta = hist > 0 ? ((predictedBudget - hist) / hist) * 100 : 0;
                        return (
                          <tr key={quarter}>
                            <td>{forecastYear}</td>
                            <td><span className="quarter-badge-sm">{quarter}</span></td>
                            <td className="td-value">
                              {new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 }).format(predictedBudget)}
                            </td>
                            <td className="td-muted">
                              {new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 }).format(hist)}
                            </td>
                            <td className={delta >= 0 ? "td-up" : "td-down"}>
                              {delta >= 0 ? "+" : ""}{delta.toFixed(2)}%
                            </td>
                            <td><span className="method-badge">ARIMA(1,1,1)</span></td>
                          </tr>
                        );
                      })}
                      <tr className="forecast-total-row">
                        <td colSpan={2}><strong>Annual Total</strong></td>
                        <td className="td-value">
                          <strong>
                            {new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 }).format(totalForecast)}
                          </strong>
                        </td>
                        <td colSpan={3} className="td-muted">ARIMA(1,1,1) — Quarter-specific models</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* ===== UPLOAD & GENERATE TAB ===== */}
      {activeTab === "upload" && (
        <div className="upload-forecast-grid">
          <DataUpload onUploadSuccess={handleUploadSuccess} />
          <div className="forecasting-panel card">
            <div className="panel-header">
              <h3>Forecasting Engine</h3>
            </div>
            <p className="panel-description">
              Generate next-year quarter-wise budget predictions using the
              <strong> ARIMA(1,1,1)</strong> model on historical data.
              Each quarter (Q1–Q4) is modelled independently to preserve seasonal patterns.
            </p>
            <div className="forecast-stats">
              <div className="forecast-stat">
                <span className="label-caps">Method</span>
                <strong>ARIMA(1,1,1)</strong>
              </div>
              <div className="forecast-stat">
                <span className="label-caps">Data Points</span>
                <strong>{budgets.length} records</strong>
              </div>
              <div className="forecast-stat">
                <span className="label-caps">Horizon</span>
                <strong>4 Quarters</strong>
              </div>
              <div className="forecast-stat">
                <span className="label-caps">Target Year</span>
                <strong>
                  {budgets.length > 0
                    ? String(
                        parseInt(
                          budgets.reduce((m, b) => (b.financialYear > m ? b.financialYear : m), "0"),
                          10
                        ) + 1
                      )
                    : "—"}
                </strong>
              </div>
            </div>
            <button
              className="btn-primary btn-generate"
              onClick={generateForecast}
              disabled={generating || budgets.length === 0}
            >
              {generating ? "⏳ Generating..." : "🔮 Generate ARIMA Forecast"}
            </button>
            {forecastMessage && (
              <div className="alert forecast-alert">{forecastMessage}</div>
            )}
          </div>
        </div>
      )}

      {/* ===== BUDGET RECORDS TAB ===== */}
      {activeTab === "records" && <BudgetManagement refreshTrigger={refreshTrigger} />}

      {/* ===== SETTINGS TAB ===== */}
      {activeTab === "settings" && (
        <div className="card" style={{ maxWidth: "400px", margin: "0 auto" }}>
          <h3>Change Password</h3>
          <form
            onSubmit={handleChangePassword}
            style={{ display: "flex", flexDirection: "column", gap: "1rem", marginTop: "1rem" }}
          >
            <div>
              <label>Current Password</label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                required
                style={{ width: "100%", padding: "0.5rem", marginTop: "0.25rem" }}
              />
            </div>
            <div>
              <label>New Password</label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                style={{ width: "100%", padding: "0.5rem", marginTop: "0.25rem" }}
              />
            </div>
            <button type="submit">Update Password</button>
            {settingsMsg && (
              <p style={{ fontSize: "0.875rem", color: "var(--color-muted)" }}>{settingsMsg}</p>
            )}
          </form>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
