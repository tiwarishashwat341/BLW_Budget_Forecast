import React, { useState } from "react";
import axios from "axios";
import "./DataUpload.css";

const API = "http://localhost:3962/api";

const DataUpload = ({ onUploadSuccess }) => {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const token = () => localStorage.getItem("adminToken");

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
    setMessage("");
    setError("");
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) return;

    setUploading(true);
    setMessage("");
    setError("");

    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await axios.post(`${API}/budget/upload`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${token()}`,
        },
      });
      setMessage(res.data.message || "✅ Upload successful!");
      setFile(null);
      // Reset file input
      const input = document.getElementById("excel-file-input");
      if (input) input.value = "";
      if (onUploadSuccess) onUploadSuccess();
    } catch (err) {
      setError(
        err.response?.data?.message ||
          err.response?.data?.error ||
          "Upload failed. Check your file format."
      );
    } finally {
      setUploading(false);
    }
  };

  const handleReset = async () => {
    if (!window.confirm("This will permanently DELETE all budget data and forecasts. Continue?"))
      return;

    setResetting(true);
    setMessage("");
    setError("");
    try {
      const res = await axios.delete(`${API}/budget/reset`, {
        headers: { Authorization: `Bearer ${token()}` },
      });
      setMessage(res.data.message || "✅ All data cleared.");
      if (onUploadSuccess) onUploadSuccess(); // refresh dashboard
    } catch (err) {
      setError(
        err.response?.data?.message ||
          err.response?.data?.error ||
          "Reset failed."
      );
    } finally {
      setResetting(false);
    }
  };

  return (
    <div className="upload-container panel">
      <h3>Data Upload</h3>
      <p>
        Upload Excel (.xlsx) file with columns:{" "}
        <strong>Year | Quarter | Budget Allocated (₹ Lakhs)</strong>
        <br />
        <small style={{ color: "var(--color-muted)" }}>
          Uploading replaces all existing data and clears old forecasts.
        </small>
      </p>
      <form onSubmit={handleUpload} className="upload-form">
        <input
          id="excel-file-input"
          type="file"
          accept=".xlsx, .xls"
          onChange={handleFileChange}
          disabled={uploading || resetting}
        />
        <button
          type="submit"
          disabled={!file || uploading || resetting}
          className="btn-primary"
        >
          {uploading ? "⏳ Uploading..." : "📂 Upload Data"}
        </button>
      </form>

      <button
        onClick={handleReset}
        disabled={resetting || uploading}
        style={{
          marginTop: "0.75rem",
          padding: "0.4rem 0.9rem",
          background: "transparent",
          border: "1px solid var(--border-color)",
          borderRadius: "6px",
          color: "var(--color-muted)",
          fontSize: "0.8rem",
          cursor: resetting ? "not-allowed" : "pointer",
          fontFamily: "var(--font-family)",
        }}
      >
        {resetting ? "Clearing…" : "🗑️ Reset All Data"}
      </button>

      {message && <div className="alert success">{message}</div>}
      {error && <div className="alert error">{error}</div>}
    </div>
  );
};

export default DataUpload;
