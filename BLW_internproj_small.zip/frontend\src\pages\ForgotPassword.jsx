import React, { useState } from "react";
import axios from "axios";
import "./Login.css"; // reuse styling

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");
    try {
      const res = await axios.post("http://localhost:3962/api/auth/forgot-password", { email });
      setMessage(res.data.message + (res.data.token ? ` Token: ${res.data.token}` : ""));
    } catch (err) {
      setError(err.response?.data?.message || "Failed to request password reset");
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h2>Forgot Password</h2>
        {error && <div className="error-message">{error}</div>}
        {message && <div className="success-message">{message}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="login-button">Send Reset Token</button>
        </form>
        <p style={{ marginTop: "0.5rem", textAlign: "center" }}>
          Remembered? <a href="/login">Login</a>
        </p>
      </div>
    </div>
  );
};

export default ForgotPassword;
